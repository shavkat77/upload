# UrlUploader
Ushbu Bot orqali URL manzilidagi fayl/video larni yuklab olishingiz mumkin
